/*********************************************************************
Homework 5
CS 110: Computer Architecture, Spring 2021
ShanghaiTech University

* Last Modified: 03/28/2021
*********************************************************************/

#include "blockchain.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/sysinfo.h>
//#include <stdio.h>
//#include <unistd.h>

int step;
size_t diff_q;
size_t diff_m;

unsigned char one_diff[HASH_BLOCK_SIZE];

pthread_t **list;
uint64_t **nonce;
void (*func_copy) (unsigned char * a,size_t b,unsigned char * c);
blk_t node_copy;


void blockchain_node_init(blk_t *node, uint32_t index, uint32_t timestamp,
                          unsigned char prev_hash[32], unsigned char *data,
                          size_t data_size) {
    if (!node || !data || !prev_hash)
    return;

    node->header.index = index;
    node->header.timestamp = timestamp;
    node->header.nonce = -1;

    memset(node->header.data, 0, sizeof(unsigned char) * 256);
    memcpy(node->header.prev_hash, prev_hash, HASH_BLOCK_SIZE);
    memcpy(node->header.data, data,
         sizeof(unsigned char) * ((data_size < 256) ? data_size : 256));
}

void blockchain_node_hash(blk_t *node, unsigned char hash_buf[HASH_BLOCK_SIZE],
                          hash_func func) {
  if (node)
    func((unsigned char *)node, sizeof(blkh_t), (unsigned char *)hash_buf);
}

BOOL blockchain_node_verify(blk_t *node, blk_t *prev_node, hash_func func) {
    unsigned char hash_buf[HASH_BLOCK_SIZE];

    if (!node || !prev_node)
    return False;

    blockchain_node_hash(node, hash_buf, func);
    if (memcmp(node->hash, hash_buf, sizeof(unsigned char) * HASH_BLOCK_SIZE))
    return False;

    blockchain_node_hash(prev_node, hash_buf, func);
    if (memcmp(node->header.prev_hash, hash_buf,
         sizeof(unsigned char) * HASH_BLOCK_SIZE))
    return False;

    return True;
}

void* thread_mine(void* param_nonce)
{
    unsigned char hash_buf[HASH_BLOCK_SIZE];
    blk_t my_node_copy = node_copy;
    my_node_copy.header.nonce = *(uint64_t*) param_nonce;

    while (my_node_copy.header.nonce <= UINT64_MAX) {

        blockchain_node_hash(&my_node_copy, hash_buf, (*func_copy));

        if ((!memcmp(hash_buf, one_diff, sizeof(unsigned char) * diff_q)) &&
            memcmp(&hash_buf[diff_q], &one_diff[diff_q],
                   sizeof(unsigned char) * (HASH_BLOCK_SIZE - diff_q)) <= 0)
        {
//            printf("I am : %lu, now it is: %lu\n", *(uint64_t*)param_nonce, my_node_copy.header.nonce);
//            pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
            for (int i = 0; i < step; ++i)
            {
                if (*(list[i]) != pthread_self()) pthread_cancel(*(list[i]));
            }

            break;
        }
        pthread_testcancel();
        (my_node_copy.header.nonce)+=step;
    }
    *(uint64_t*)param_nonce = my_node_copy.header.nonce;


    pthread_exit(NULL);
}


/* The sequiental implementation of mining implemented for you. */
void blockchain_node_mine(blk_t *node, unsigned char hash_buf[HASH_BLOCK_SIZE],
                          size_t diff, hash_func func)
{
    /* Set the standard value */
    diff_q = diff / 8;
    diff_m = diff % 8;
    memset(one_diff, 0xFF, sizeof(unsigned char) * HASH_BLOCK_SIZE);
    memset(one_diff, 0, sizeof(unsigned char) * diff_q);
    one_diff[diff_q] = ((uint8_t)0xFF) >> diff_m;
    func_copy = func;
    node_copy = *node;



    /* Set how many threads we want to use */
    step = get_nprocs()*2;
    if (diff <= 10) step = 2;
    if (diff >10 && diff <= 16) step = 4;
    if (diff >16 && diff <= 18) step = 16;
//    printf("#core: %d\n", step);

    /* allocate space of threads and nonces */
    list = malloc(sizeof(pthread_t*) * step);
    nonce = malloc(sizeof(uint64_t*) * step);


    /* create and run the threads */
    for (int i = 0; i < step; i++)
    {
        nonce[i] = malloc(sizeof(uint64_t));
        list[i] = malloc(sizeof(pthread_t));
        *(nonce[i]) = i - 1;
    }
    for (int i = 0; i < step; i++)
    {
        pthread_create(list[i], NULL, thread_mine, nonce[i]);
    }


    /* Identify the results, join the threads, save the nouce and hash_buf */
    for (int i = 0; i < step; i++) pthread_join(*(list[i]), NULL);
    for (int i = 0; i < step; i++)
    {
        node->header.nonce = *(nonce[i]);

        blockchain_node_hash(node, hash_buf, func);
        if ((!memcmp(hash_buf, one_diff, sizeof(unsigned char) * diff_q)) &&
            memcmp(&hash_buf[diff_q], &one_diff[diff_q],
                   sizeof(unsigned char) * (HASH_BLOCK_SIZE - diff_q)) <= 0)
        {
            memcpy(node->hash, hash_buf, sizeof(unsigned char) * HASH_BLOCK_SIZE);
            break;
        }

    }



    /* clear the allocate memory */
    for (int i = 0; i < step; i++)
    {
        free(nonce[i]);
        free(list[i]);
    }
    free(list);
    free(nonce);

}
